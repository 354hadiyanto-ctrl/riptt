# RIPT — Rabbit Integrated Processing Technology

Prototype web/mobile ecosystem untuk Rabbit Fresh.

## Struktur

```text
RIPT/
├── index.html
├── apps/
│   ├── operator.html
│   └── partner.html
├── README.md
└── .nojekyll
```

## Experience

- **RIPT.Operator** — operational/processing experience.
- **RIPT.Partner** — upstream/partner farmer experience.
- **Landing page** — role selector dan overview ekosistem RIPT.

## Menjalankan lokal

Tidak membutuhkan build step.

1. Download/clone repository.
2. Buka `index.html` dengan browser, atau gunakan Live Server.
3. Pilih Operator atau Partner.

## GitHub Pages

Repository dapat dipublish langsung menggunakan GitHub Pages dari branch `main`, folder `/root`.

## Catatan MVP

Data pada prototype masih berupa dummy/front-end state. Belum ada backend, authentication, database, API, QR persistence, atau multi-user synchronization.

Tahap berikutnya dapat menggunakan backend/database untuk menghubungkan:
`RPSS™ → RabbitSafe Process™ → Product Lot → RabbitCycle™ → RabbitBio™`
